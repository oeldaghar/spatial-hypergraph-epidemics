graphs in this directory are stored in a hyperedge format so each line in the file corresponds to a hyperedge. file names follow the format 

"spatial-hypergraph-nnodes-ndimensions-alpha-randomseed.txt"
"spatial-hypergraph-nnodes-ndimensions-alpha-randomseed.xy"

where the *.xy files are node coordinates.